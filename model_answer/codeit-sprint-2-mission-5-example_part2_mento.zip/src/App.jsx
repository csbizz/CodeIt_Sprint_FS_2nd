import { SecondHandMarket } from "./pages/SecondHandMarket"

export function App() {
  return (
    <>
      {/* react router */}
      <SecondHandMarket />
    </>
  )
}
