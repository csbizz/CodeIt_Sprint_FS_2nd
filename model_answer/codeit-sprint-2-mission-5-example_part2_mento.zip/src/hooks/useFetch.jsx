import { useEffect, useState } from "react"
const serverBaseUrl = "https://panda-market-api.vercel.app"

export function useFetch(
  path = "/",
  options = {
    method: "GET"
  },
  params = {}
) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const queryString = new URLSearchParams(params).toString()

  useEffect(() => {
    setLoading(true)
    ;(async () => {
      const headers = {
        "Content-Type": "application/json",
        ...options.headers
      }

      const body = options.body ? JSON.stringify(options.body) : null

      try {
        const res = await fetch(`${serverBaseUrl}${path}?${queryString}`, {
          headers,
          body,
          ...options
        }).then((res) => res.json())

        setData(res)
      } catch (err) {
        setError(err)
      } finally {
        setLoading(false)
      }
    })()
  }, [queryString])

  if (error) {
    throw new Error(error)
  }

  return { data, loading }
}
