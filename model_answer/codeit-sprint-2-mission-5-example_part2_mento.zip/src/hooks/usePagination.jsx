import { useEffect, useState } from "react"

export function usePagination(totalItems, itemsPerPage, initPage = 1) {
  const [curPage, setCurPage] = useState(initPage)
  const [totalPage, setTotalPage] = useState(
    Math.ceil(totalItems / itemsPerPage)
  )

  useEffect(() => {
    // 총 아이템 or 페이지 당 개수가 변경되면 총 페이지 수 재계산
    setTotalPage(Math.ceil(totalItems / itemsPerPage))
  }, [totalItems, itemsPerPage])

  const nextPage = () => {
    setCurPage((prev) => Math.min(prev + 1, totalPage))
  }

  const prevPage = () => {
    setCurPage((prev) => Math.max(prev - 1, 1))
  }

  const goToPage = (page) => {
    setCurPage(Math.max(Math.min(page, totalPage), 1))
  }

  return {
    curPage,
    nextPage,
    prevPage,
    goToPage,
    totalPage
  }
}
