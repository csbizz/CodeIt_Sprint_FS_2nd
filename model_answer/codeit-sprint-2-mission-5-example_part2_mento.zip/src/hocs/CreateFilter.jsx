import { useState } from "react"
import { useViewport } from "../contexts/viewportContext"
import "../css/CreateFilter.css"
import arrowDownIcon from "../images/arrowDownIcon.svg"
import sortIcon from "../images/sortIcon.svg"

export function CreateFilter({
  items = {
    recent: "최신순",
    favorite: "좋아요순"
  }
}) {
  const itemArr = Object.entries(items)

  return function Filter() {
    const viewport = useViewport()
    const isMobile = viewport === "mobile"
    const [selected, setSelected] = useState(itemArr[0][0])
    const [isDropdownOpen, setIsDropdownOpen] = useState(false)

    const handleDropdownClick = () => {
      setIsDropdownOpen(!isDropdownOpen)
    }

    const handleItemClick = (item) => {
      setSelected(item)
    }

    return (
      <div className="filter-select" onClick={handleDropdownClick}>
        <div className="selected-item">
          <span className="selected-text">{items[selected]}</span>
          <img
            className="selected-image"
            src={isMobile ? sortIcon : arrowDownIcon}
            alt="arrow-down"
          />
        </div>
        <div
          className="dropdown"
          style={{ display: isDropdownOpen ? "block" : "none" }}>
          {itemArr.map((item, i) => (
            <div
              key={i}
              className="item"
              value={item[0]}
              onClick={() => handleItemClick(item[0])}>
              {item[1]}
            </div>
          ))}
        </div>
      </div>
    )
  }
}
