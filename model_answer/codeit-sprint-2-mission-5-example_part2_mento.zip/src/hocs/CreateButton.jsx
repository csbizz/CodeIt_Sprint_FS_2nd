import "../css/CreateButton.css"

export function createButton({
  buttonType = "",
  backgroundColor = "",
  color = ""
}) {
  return function Button({ children, onClick = () => {} }) {
    return (
      <button
        onClick={onClick}
        className={`${buttonType} ${backgroundColor} ${color}`}>
        {children}
      </button>
    )
  }
}
