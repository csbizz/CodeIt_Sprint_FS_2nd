import { ProductCard } from "../components/ProductCard"
import "../css/CreateProductCardList.css"
import { useFetch } from "../hooks/useFetch"

export function CreateProductCardList({ col = 5, row = 2 }) {
  const gridStyle = {
    gridTemplateColumns: `repeat(${col}, ${row}fr)`
  }

  return function ProductCardList({
    page = 1,
    orderBy = "recent",
    keyword = ""
  }) {
    const { data, loading } = useFetch(
      "/products",
      {
        method: "GET"
      },
      {
        page,
        pageSize: col * row,
        orderBy,
        keyword
      }
    )

    return (
      <div className="product-card-list" style={gridStyle}>
        {loading ||
          data?.list?.map((item, i) => <ProductCard key={i} item={item} />)}
      </div>
    )
  }
}
