import "../css/MainLayout.css"

export function MainLayout({ children }) {
  return <main className="main">{children}</main>
}
