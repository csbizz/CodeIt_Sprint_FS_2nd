import { useEffect, useState } from "react"
import { useViewport } from "../contexts/viewportContext"
import "../css/GNB.css"
import pandaLogo from "../images/pandaLogoSm.svg"
import pandaTypo from "../images/pandaLogoTypo.svg"
import { createButton } from "../hocs/CreateButton"

const LoginButton = createButton({
  buttonType: "small-button",
  backgroundColor: "bg-primary-100",
  color: "txt-gray-100"
})

export function GNB() {
  const viewport = useViewport()
  const [logoImg, setLogoImg] = useState(
    viewport === "mobile" ? pandaTypo : pandaLogo
  )

  useEffect(() => {
    setLogoImg(viewport === "mobile" ? pandaTypo : pandaLogo)
  }, [viewport])

  return (
    <header className="gnb">
      <div className="gnb-container">
        <div className="gnb-left">
          <img className="logo" src={logoImg} alt="pandaLogo" />
          <div className="menu-container">
            <div className="menu">자유게시판</div>
            <div className="menu">중고마켓</div>
          </div>
        </div>
        <LoginButton>로그인</LoginButton>
      </div>
    </header>
  )
}
