import "../css/Footer.css"
import facebookIcon from "../images/facebookIcon.svg"
import instagramIcon from "../images/instagramIcon.svg"
import twitterIcon from "../images/twitterIcon.svg"
import youtubeIcon from "../images/youtubeIcon.svg"

export function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="copyright">©codeit - 2024</div>
        <div className="policy">
          <div>Privacy Policy</div>
          <div>FAQ</div>
        </div>
        <div className="sns-container">
          <img src={facebookIcon} alt="facebook" />
          <img src={twitterIcon} alt="twitter" />
          <img src={instagramIcon} alt="instagram" />
          <img src={youtubeIcon} alt="youtube" />
        </div>
      </div>
    </footer>
  )
}
