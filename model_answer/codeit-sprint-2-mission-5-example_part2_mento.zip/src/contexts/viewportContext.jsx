import { createContext, useContext, useEffect, useState } from "react"

const breakpoints = Object.freeze({
  mobile: 743,
  tablet: 1199
})

const viewportContext = createContext()

export function ViewportProvider({ children }) {
  const [viewport, setViewport] = useState(() => {
    if (window.innerWidth <= breakpoints.mobile) {
      return "mobile"
    }

    if (window.innerWidth <= breakpoints.tablet) {
      return "tablet"
    }

    return "desktop"
  })

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= breakpoints.mobile) {
        return setViewport("mobile")
      }

      if (window.innerWidth <= breakpoints.tablet) {
        return setViewport("tablet")
      }

      return setViewport("desktop")
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <viewportContext.Provider value={viewport}>
      {children}
    </viewportContext.Provider>
  )
}

export function useViewport() {
  const viewport = useContext(viewportContext)
  if (!viewport) {
    throw new Error("useViewport must be used within a ViewportProvider")
  }

  return viewport
}
