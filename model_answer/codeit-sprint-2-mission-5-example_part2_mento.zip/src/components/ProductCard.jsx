import { useState } from "react"
import "../css/ProductCard.css"
import heartIcon from "../images/heartIcon.svg"
import productDefaultImage from "../images/productDefault.svg"

function formatPrice(price) {
  return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
}

export function ProductCard({ item }) {
  const { name, price, images, favoriteCount } = item

  const [productImage, setProductImage] = useState(images[0])

  const handleImageError = () => {
    setProductImage(productDefaultImage)
  }

  return (
    <div className="product-card">
      <div className="image-container">
        <img
          className="image"
          src={productImage}
          alt={name + " image"}
          onError={handleImageError}
        />
      </div>
      <div className="product-card-info">
        <div className="name">{name}</div>
        <div className="price">{formatPrice(price)}원</div>
        <div className="heart-cnt">
          <img
            className="heart-icon"
            src={heartIcon}
            alt="heart icon"
            width={16}
            height={16}
          />
          <span>{favoriteCount}</span>
        </div>
      </div>
    </div>
  )
}
