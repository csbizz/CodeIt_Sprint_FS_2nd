import { useEffect, useState } from "react"
import "../css/PaginationBar.css"
import prevIconActive from "../images/arrowLeft.svg"
import prevIconDisabled from "../images/arrowLeftDisabled.svg"
import nextIconActive from "../images/arrowRight.svg"
import nextIconDisabled from "../images/arrowRightDisabled.svg"

export function PaginationBar({
  curPage = 1,
  totalPage = 10,
  curPagePositionIndex = 0, // 현재 페이지가 bar의 몇 번째에 위치하는지
  maxCntPerBar = 5, // bar에 한번에 노출될 최대 페이지 수
  handleNextPage = () => {},
  handlePrevPage = () => {},
  handleGoToPage = () => {}
}) {
  const curBarCnt = Math.min(maxCntPerBar, totalPage)
  const startPageNum = curPage - curPagePositionIndex
  const pageList = Array.from({ length: curBarCnt }, (_, i) => startPageNum + i)

  const [prevIcon, setPrevIcon] = useState(prevIconActive)
  const [nextIcon, setNextIcon] = useState(nextIconActive)

  const isPrevDisabled = curPage === 1
  const isNextDisabled = curPage === totalPage

  useEffect(() => {
    if (isPrevDisabled) {
      setPrevIcon(prevIconDisabled)
      setNextIcon(nextIconActive)
      return
    }

    if (isNextDisabled) {
      setPrevIcon(prevIconActive)
      setNextIcon(nextIconDisabled)
      return
    }
  }, [curPage])

  return (
    <div className="pagination-bar-container">
      <button
        className="prev-btn"
        onClick={handlePrevPage}
        disabled={isPrevDisabled}>
        <img src={prevIcon} alt="prev-btn" />
      </button>
      {pageList.map((page) => (
        <button
          className={`page-btn ${page === curPage ? "active" : ""}`}
          onClick={() => handleGoToPage(page)}
          key={page}>
          {page}
        </button>
      ))}
      <button
        className="next-btn"
        onClick={handleNextPage}
        disabled={isNextDisabled}>
        <img src={nextIcon} alt="next-btn" />
      </button>
    </div>
  )
}
