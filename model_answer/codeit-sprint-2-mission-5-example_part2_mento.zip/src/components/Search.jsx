import "../css/Search.css"
import searchIcon from "../images/searchIcon.svg"

export function Search({ enterEvent = () => {} }) {
  const handleEnter = (e) => {
    if (e.key === "Enter") {
      enterEvent()
    }
  }

  return (
    <div className="search-container">
      <img className="search-icon" src={searchIcon} alt="search icon" />
      <input
        onKeyDown={handleEnter}
        className="search-input"
        type="text"
        placeholder="검색어를 입력해주세요"
      />
    </div>
  )
}
