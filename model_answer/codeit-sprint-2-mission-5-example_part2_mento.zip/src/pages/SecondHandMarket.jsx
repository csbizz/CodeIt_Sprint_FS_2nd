import { useEffect, useState } from "react"
import { PaginationBar } from "../components/PaginationBar"
import { Search } from "../components/Search"
import { useViewport } from "../contexts/viewportContext"
import "../css/SecondHandMarket.css"
import { createButton } from "../hocs/CreateButton"
import { CreateFilter } from "../hocs/CreateFilter"
import { CreateProductCardList } from "../hocs/CreateProductCardList"
import { usePagination } from "../hooks/usePagination"
import { Footer } from "../layouts/Footer"
import { GNB } from "../layouts/GNB"
import { MainLayout } from "../layouts/MainLayout"

const gridTable = Object.freeze({
  desktop: {
    bestProduct: { col: 4, row: 1 },
    onSaleProduct: { col: 5, row: 2 }
  },
  tablet: {
    bestProduct: { col: 2, row: 1 },
    onSaleProduct: { col: 3, row: 2 }
  },
  mobile: {
    bestProduct: { col: 1, row: 1 },
    onSaleProduct: { col: 2, row: 2 }
  }
})

// 판매 중인 상품 기능
const AddProductButton = createButton({
  buttonType: "small-button",
  backgroundColor: "bg-primary-100",
  color: "txt-gray-100"
})

const FilterSelect = CreateFilter({
  items: {
    recent: "최신순",
    favorite: "좋아요순"
  }
})

export function SecondHandMarket() {
  const viewport = useViewport()

  // 베스트 상품
  const [bestProductGrid, setBestProductGrid] = useState(
    gridTable[viewport].bestProduct
  )
  const BestProductCardList = CreateProductCardList(bestProductGrid)

  // 판매 중인 상품
  const [onSaleProductGrid, setOnSaleProductGrid] = useState(
    gridTable[viewport].onSaleProduct
  )
  const OnSaleProductCardList = CreateProductCardList(onSaleProductGrid)

  // pagination
  // const [] = usePagination()

  useEffect(() => {
    setBestProductGrid(gridTable[viewport].bestProduct)
    setOnSaleProductGrid(gridTable[viewport].onSaleProduct)
  }, [viewport])

  return (
    <>
      <GNB />
      <MainLayout>
        <div className="main-container">
          <div className="best-product-container">
            <div className="title">베스트 상품</div>
            <BestProductCardList page={1} orderBy="favorite" />
          </div>
          <div className="on-sale-product-container">
            <div className="header-container">
              <div className="title">판매 중인 상품</div>
              <Search />
              <AddProductButton>상품 등록하기</AddProductButton>
              <FilterSelect />
            </div>
            <OnSaleProductCardList page={1} orderBy="recent" />
            <PaginationBar />
          </div>
        </div>
      </MainLayout>
      <Footer />
    </>
  )
}
