export class ProductService {
  constructor(productModel) {
    this.productModel = productModel
  }
}
