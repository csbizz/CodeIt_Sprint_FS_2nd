import React from "react";

function AddItemPage() {
  return <div>AddItemPage</div>;
}

export default AddItemPage;
