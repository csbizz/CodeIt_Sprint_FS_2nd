import React from "react";

function CommunityFeedPage() {
  return <div>CommunityFeedPage</div>;
}

export default CommunityFeedPage;
