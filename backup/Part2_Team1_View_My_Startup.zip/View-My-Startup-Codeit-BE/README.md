# View-My-Startup-Codeit-BE

View-My-Startup Codeit Back-End

각자 .env 파일을 최상위 디렉토리에 만들어서

```
DATABASE_URL="postgresql://postgres:[password]@localhost:5432/view_my_startup_dev?schema=public"
PORT=3000
```

과 같은 값을 넣어줍시다.
