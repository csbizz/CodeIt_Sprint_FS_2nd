class CONSTANTS {
	static MESSAGES = Object.freeze({
		NOID: 'Cannot find given id.',
		IDFORMAT: 'Invalid id format.',
		UNAUTHORIZED: 'Wrong password',
	});
}

export default CONSTANTS;
