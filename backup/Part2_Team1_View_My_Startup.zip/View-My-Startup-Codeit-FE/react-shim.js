import React from 'react';

export { React };
