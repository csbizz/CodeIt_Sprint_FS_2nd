node ./esbuild.config.js
