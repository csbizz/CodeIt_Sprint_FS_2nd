function NotFoundPage() {
	return <h1>존재하지 않는 페이지입니다.</h1>;
}

export default NotFoundPage;
