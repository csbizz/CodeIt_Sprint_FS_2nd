declare module 'is-uuid' {
  const v4: (value: string) => boolean;
  export { v4 };
}