declare module 'is-email' {
  const isEmail: (value: string) => boolean;
  export default isEmail;
}
