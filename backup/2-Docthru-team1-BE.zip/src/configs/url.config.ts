export const baseUrlLocal = process.env.BASE_URL_LOCAL;
export const baseUrlEC2 = process.env.BASE_URL_EC2;
