import * as deepl from 'deepl-node';
import { deeplApiKey } from '#configs/deepl.config.js';
import deeplTranslate from '#utils/deepl-translate.js';

const translator = new deepl.Translator(deeplApiKey);

const test = [
  'Royal Feast Challenge: Exploring Korean Court Cuisine',
  'Step into the grandeur of Korea’s royal history with the Royal Feast Challenge! Discover the elegance and sophistication of Korean Court Cuisine, once served to kings and queens of the Joseon Dynasty. This challenge invites you to prepare iconic dishes like Sinseollo (royal hot pot), Gujeolpan (platter of nine delicacies), and Japchae (stir-fried glass noodles), each showcasing the harmony of flavors and artistry that define royal dining.',
  'Join us as we celebrate tradition, elevate your culinary skills, and savor the taste of Korean heritage!',
];

const result = await deeplTranslate(test);
console.log(result);
