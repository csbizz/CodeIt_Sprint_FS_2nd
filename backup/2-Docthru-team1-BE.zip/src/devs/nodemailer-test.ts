import transporter from '#utils/nodemailer/transporter.js';

const message = {
  from: 'forCodeitFS2nd@gmail.com',
  to: 'forCodeitFS2nd@gmail.com',
  subject: 'test title2',
  text: 'test',
};

transporter.sendMail(message);
