export interface UpdateNotificationDTO {
  isRead: boolean;
}
