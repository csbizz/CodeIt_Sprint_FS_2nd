const FEEDBACKS = [
  {
    content: 'feedback content1',
    ownerId: 'e8394ccc-7359-4c16-ab37-4ed9671146a4',
    workId: 'dcacba47-d7f3-4b06-af49-cdb4296b6563',
  },
  {
    content: 'feedback content2',
    ownerId: 'c19d6446-2c05-48d7-99d2-9c12d2baa868',
    workId: 'dcacba47-d7f3-4b06-af49-cdb4296b6563',
  },
  {
    content: 'feedback content3',
    ownerId: 'e8394ccc-7359-4c16-ab37-4ed9671146a4',
    workId: 'dcacba47-d7f3-4b06-af49-cdb4296b6563',
  },
  {
    content: 'feedback content4',
    ownerId: 'c19d6446-2c05-48d7-99d2-9c12d2baa868',
    workId: 'dcacba47-d7f3-4b06-af49-cdb4296b6563',
  },
  {
    content: 'feedback content5',
    ownerId: '78dd77e8-36e4-4cbd-bd7b-27e7fcaae6f9',
    workId: '6d2ec97d-8376-4600-99a8-9a1e2c386c31',
  },
  {
    content: 'feedback content6',
    ownerId: 'a666a76c-46a1-4aa2-9741-bdbb20785fc4',
    workId: '2f11bea0-f22f-4411-8111-e7bfd0590967',
  },
  {
    content: 'feedback content7',
    ownerId: 'c19d6446-2c05-48d7-99d2-9c12d2baa868',
    workId: '2f11bea0-f22f-4411-8111-e7bfd0590967',
  },
  {
    content: 'feedback content8',
    ownerId: 'a666a76c-46a1-4aa2-9741-bdbb20785fc4',
    workId: '2f11bea0-f22f-4411-8111-e7bfd0590967',
  },
  {
    content: 'feedback content9',
    ownerId: 'c19d6446-2c05-48d7-99d2-9c12d2baa868',
    workId: '3fe920eb-86e7-403a-b898-d624667ca15c',
  },
  {
    content: 'feedback content10',
    ownerId: '78dd77e8-36e4-4cbd-bd7b-27e7fcaae6f9',
    workId: '3fe920eb-86e7-403a-b898-d624667ca15c',
  },
];

export default FEEDBACKS;
