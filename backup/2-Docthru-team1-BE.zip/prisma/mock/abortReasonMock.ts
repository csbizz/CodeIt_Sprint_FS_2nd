export const ABORT_REASONS = [
  {
    content: '거절,취소 사유',
    adminId: '590602e9-3796-4287-bca1-de9969139fbc',
    challengeId: 'd0611542-61b2-4ff1-8e3d-745413cdfce5',
  },
  {
    content: '거절,취소 사유',
    adminId: '590602e9-3796-4287-bca1-de9969139fbc',
    challengeId: '3508f13c-7399-48d1-b35a-a9e5e2ed4b06',
  },
  {
    content: '거절,취소 사유',
    adminId: '590602e9-3796-4287-bca1-de9969139fbc',
    challengeId: 'c756848e-8940-41bd-959f-68e0f34563fc',
  },
  {
    content: '거절,취소 사유',
    adminId: '590602e9-3796-4287-bca1-de9969139fbc',
    challengeId: 'fc299a7d-9b3f-4ac6-afa5-17d035bc3388',
  },
];
