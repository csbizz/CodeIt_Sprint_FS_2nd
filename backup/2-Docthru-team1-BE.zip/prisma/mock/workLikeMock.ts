export const WORK_LIKES = [
  {
    createdAt: '2024-12-01T10:15:30Z',
    updatedAt: '2024-12-01T10:15:30Z',
    userId: 'e8394ccc-7359-4c16-ab37-4ed9671146a4',
    challengeWorkId: 'dcacba47-d7f3-4b06-af49-cdb4296b6563',
  },
  {
    createdAt: '2024-12-02T14:20:45Z',
    updatedAt: '2024-12-02T14:20:45Z',
    userId: 'c19d6446-2c05-48d7-99d2-9c12d2baa868',
    challengeWorkId: 'dcacba47-d7f3-4b06-af49-cdb4296b6563',
  },
  {
    createdAt: '2024-12-03T09:05:10Z',
    updatedAt: '2024-12-03T09:05:10Z',
    userId: '0081e090-abfa-4e86-a13d-3cba9539a06c',
    challengeWorkId: 'e233182b-4746-4d61-983e-b87cd302e68b',
  },
  {
    createdAt: '2024-12-03T16:30:00Z',
    updatedAt: '2024-12-03T16:30:00Z',
    userId: '5f72c907-e528-4e38-8b4e-c602417ae8af',
    challengeWorkId: '6d2ec97d-8376-4600-99a8-9a1e2c386c31',
  },
  {
    createdAt: '2024-12-04T08:45:25Z',
    updatedAt: '2024-12-04T08:45:25Z',
    userId: '143c6a80-3522-41e9-a2ed-c57cbdb18f75',
    challengeWorkId: '3eb9b648-6363-418d-96da-5bc230d3a134',
  },
  {
    createdAt: '2024-12-04T11:00:15Z',
    updatedAt: '2024-12-04T11:00:15Z',
    userId: 'bb92be3c-8771-4fe1-aa33-dfeef8061ebe',
    challengeWorkId: '2f11bea0-f22f-4411-8111-e7bfd0590967',
  },
  {
    createdAt: '2024-12-04T12:30:50Z',
    updatedAt: '2024-12-04T12:30:50Z',
    userId: '590602e9-3796-4287-bca1-de9969139fbc',
    challengeWorkId: 'dcacba47-d7f3-4b06-af49-cdb4296b6563',
  },
];
