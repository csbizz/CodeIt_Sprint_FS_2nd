-- AlterTable
ALTER TABLE "Recipe" ALTER COLUMN "likeCount" SET DEFAULT 0;
