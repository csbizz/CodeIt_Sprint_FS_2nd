-- AlterTable
ALTER TABLE "Notification" ALTER COLUMN "deletedAt" DROP NOT NULL;
