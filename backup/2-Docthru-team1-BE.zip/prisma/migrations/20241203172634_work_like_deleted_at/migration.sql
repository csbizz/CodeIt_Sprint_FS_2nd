-- AlterTable
ALTER TABLE "WorkLike" ADD COLUMN     "deletedAt" TIMESTAMP(3);
