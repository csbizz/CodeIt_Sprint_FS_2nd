-- AlterTable
ALTER TABLE "ChallengeWork" ALTER COLUMN "likeCount" SET DEFAULT 0;
