import type { ReactNode } from 'react';

export interface CtaProps {
  children: ReactNode;
  url: string;
}
