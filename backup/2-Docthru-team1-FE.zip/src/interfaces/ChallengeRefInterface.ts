export interface ChallengeRefPageCardProps {
  embedUrl: string;
}
