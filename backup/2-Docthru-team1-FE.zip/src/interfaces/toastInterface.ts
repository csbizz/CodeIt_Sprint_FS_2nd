export interface ToastProps {
  onClose: () => void;
  duration?: number;
  onYesClick: () => void;
}
