export interface OptionBoxProps {
  type: 'onGoing' | 'finished' | 'participate';
  id: string;
  date: string;
  url: string;
}
