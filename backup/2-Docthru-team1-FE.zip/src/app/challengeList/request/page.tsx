import ChallengeRequestClient from '@/components/ClientWrapper/ChallengeRequestClient';

export default async function ChallengeListPage() {
  return <ChallengeRequestClient />;
}
