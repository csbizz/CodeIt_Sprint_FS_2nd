import ChallengeTryClient from '@/components/ClientWrapper/ChallengeTryClient';

export default function EditPage() {
  return <ChallengeTryClient />;
}
