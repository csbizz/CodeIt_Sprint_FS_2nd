import ChallengeDetailClient from '@/components/ClientWrapper/ChallengeDetailClient';

export default function ChallengeDetailPage() {
  return <ChallengeDetailClient />;
}
