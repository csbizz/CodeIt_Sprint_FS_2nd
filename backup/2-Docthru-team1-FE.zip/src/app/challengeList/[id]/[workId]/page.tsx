import WorkDetailClient from '@/components/ClientWrapper/WorkDetailClient';

export default function WorkPage() {
  return <WorkDetailClient />;
}
