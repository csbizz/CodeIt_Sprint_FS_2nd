import MyChallengeDetailClient from '@/components/ClientWrapper/MyChallengeDetailClient';

export default function MyChallengeDetailPage() {
  return <MyChallengeDetailClient />;
}
