import MyChallengeClient from '@/components/ClientWrapper/MyChallengeClient';

export default function MyPage() {
  return <MyChallengeClient />;
}
