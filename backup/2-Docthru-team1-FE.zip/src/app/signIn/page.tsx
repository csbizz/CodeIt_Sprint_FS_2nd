import SignIn from '@/components/ClientWrapper/SignInClient';

export default function SignInPage() {
  return <SignIn />;
}
