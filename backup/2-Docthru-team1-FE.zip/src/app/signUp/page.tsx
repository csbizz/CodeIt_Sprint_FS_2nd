import SignUpClient from '@/components/ClientWrapper/SignUpClient';

export default function SignUpPage() {
  return (
    <div>
      <SignUpClient />
    </div>
  );
}
