import ChallengeMgmtClient from '@/components/ClientWrapper/ChallengeMgmtClient';

export default function challengeMgmt() {
  return <ChallengeMgmtClient />;
}
