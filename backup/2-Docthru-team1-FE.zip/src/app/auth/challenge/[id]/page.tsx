import AdminChallengeDetailClient from '@/components/ClientWrapper/AdminChallengeDetailClient';

export default function AuthChallengeDetailPage() {
  return <AdminChallengeDetailClient />;
}
