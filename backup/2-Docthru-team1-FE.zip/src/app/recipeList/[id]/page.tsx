import RecipeDetailClient from '@/components/ClientWrapper/RecipeDetailClient';

export default function RecipeDetail() {
  return (
    <div>
      <RecipeDetailClient />
    </div>
  );
}
